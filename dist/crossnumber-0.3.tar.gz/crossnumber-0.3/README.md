# Crossnumber
A collection of Python functions which may be of use when solving crossnumber puzzles

## Installation
pip3 install crossnumber

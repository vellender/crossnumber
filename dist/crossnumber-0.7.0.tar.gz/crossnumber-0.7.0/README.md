# Crossnumber
A collection of Python functions which may be of use when solving crossnumber puzzles.

## Documentation
See [the documtation on readthedocs](https://crossnumber.readthedocs.io).

## Installation
pip3 install crossnumber
